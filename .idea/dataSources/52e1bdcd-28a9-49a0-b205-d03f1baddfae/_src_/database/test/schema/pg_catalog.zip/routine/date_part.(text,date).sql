create function pg_catalog.date_part(text, date) returns double precision
LANGUAGE SQL
AS $$
select pg_catalog.date_part($1, cast($2 as timestamp without time zone))
$$;
