create function pg_catalog.rpad(text, integer) returns text
LANGUAGE SQL
AS $$
select pg_catalog.rpad($1, $2, ' ')
$$;
